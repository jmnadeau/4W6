import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DemoImage';
  progress = 0;
  @ViewChild('fileuploadviewchild', {static:false}) fileuploadviewchild: ElementRef;
  @ViewChild('fileuploadprogress', {static:false}) fileuploadprogress: ElementRef;

  constructor(public http: HttpClient) { }

  uploadOnChange(file: File) {
    let formData = new FormData();
    formData.append('file', file, file.name);

    this.http.post('https://localhost:44336/api/images',formData).subscribe();
  }

  uploadViewChild() {
    let file: File = this.fileuploadviewchild.nativeElement.files[0];
    let formData = new FormData();
    formData.append('file', file, file.name);

    this.http.post('https://localhost:44336/api/images',formData).subscribe();
  }

  uploadWithProgress() {
    let file: File = this.fileuploadprogress.nativeElement.files[0];
    let formData = new FormData();
    formData.append('file', file, file.name);

    this.http.post('https://localhost:44336/api/images',formData,{reportProgress: true,observe:'events'})
      .subscribe(event => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = Math.round(100 * event.loaded / event.total);
        } else if (event.type === HttpEventType.Response) {
          console.log('Photo chargée');
          this.progress = 100;
        }
      });
  }
}
