﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoImage.Data;
using DemoImage.Models;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;

namespace DemoImage.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly DemoImageContext _context;

        public ImagesController(DemoImageContext context)
        {
            _context = context;
        }

        // GET: api/Images
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Photo>>> GetImage()
        {
            return await _context.Photos.ToListAsync();
        }

        // GET: api/Images/5
        [HttpGet("{size}/{id}")]
        public async Task<IActionResult> GetImage(string size, int id)
        {
            Photo photo = await _context.Photos.FindAsync(id);

            byte[] bytes = System.IO.File.ReadAllBytes("C://images/" + size + "/" + photo.Filename);

            return File(bytes, photo.MimeType);
        }

        // POST: api/Images
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<Photo>> PostImage()
        {
            try
            {
                IFormCollection formCollection = await Request.ReadFormAsync();
                IFormFile file = formCollection.Files.First();

                Image image = Image.Load(file.OpenReadStream());
                Photo photo = new Photo();

                photo.MimeType = file.ContentType;
                photo.Filename = Guid.NewGuid().ToString();
                if (photo.MimeType == "image/jpeg")
                    photo.Filename += ".jpg";

                image.Save("C://images/lg/" + photo.Filename);
                image.Mutate(i => {
                    i.Resize(new ResizeOptions()
                    {
                        Mode = ResizeMode.Min,
                        Size = new Size() { Height = 720 }
                    });
                });
                image.Save("C://images/md/" + photo.Filename);
                image.Mutate(i => {
                    i.Resize(new ResizeOptions()
                    {
                        Mode = ResizeMode.Min,
                        Size = new Size() { Height = 320 }
                    });
                });
                image.Save("C://images/sm/" + photo.Filename);


                _context.Photos.Add(photo);
                _context.SaveChanges();
            }
            catch(Exception e) {
            
            }
            return Ok();
        }

        // DELETE: api/Images/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteImage(int id)
        {
            var image = await _context.Photos.FindAsync(id);
            if (image == null)
            {
                return NotFound();
            }

            _context.Photos.Remove(image);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ImageExists(int id)
        {
            return _context.Photos.Any(e => e.Id == id);
        }
    }
}
