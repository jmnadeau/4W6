﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DemoImage.Models;

namespace DemoImage.Data
{
    public class DemoImageContext : DbContext
    {
        public DemoImageContext (DbContextOptions<DemoImageContext> options)
            : base(options)
        {
        }

        public DbSet<DemoImage.Models.Photo> Photos { get; set; }
    }
}
